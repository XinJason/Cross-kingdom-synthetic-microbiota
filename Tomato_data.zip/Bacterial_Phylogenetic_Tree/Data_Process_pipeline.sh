[TOC]
#!/bin/bash
# Xin Zhou


mkdir -p result/tree
cd result/tree

tail -n+2 ../otutab_rare.txt | wc -l

usearch11 -otutab_trim ./otutab_rare.txt \
    -min_otu_freq 0.001 \
    -output otutab.txt

tail -n+2 otutab.txt | wc -l

cut -f 1 otutab.txt | sed '1 s/#OTU ID/OTUID/' > otutab_high.id


usearch11 -fastx_getseqs ../otus.fa -labels otutab_high.id \
    -fastaout otus.fa
head -n 2 otus.fa


awk 'NR==FNR{a[$1]=$0} NR>FNR{print a[$1]}' ./taxonomy.txt \
    otutab_high.id > otutab_high.tax

awk 'NR==FNR{a[$1]=$0} NR>FNR{print a[$1]}' ./otutab_mean.txt otutab_high.id \
    | sed 's/#OTU ID/OTUID/' > otutab_high.mean
head -n3 otutab_high.mean


cut -f 2- otutab_high.mean > temp
paste otutab_high.tax temp > annotation.txt
head -n 3 annotation.txt


time muscle -in otus.fa -out otus_aligned.fas

#trimAL
trimal -in otus_aligned.fas -out otus_aligned_trimed.fa -gt 0.95

mkdir -p iqtree
time ./${db}/win/iqtree -s  otus_aligned_trimed.fa \
        -bb 1000 -redo -alrt 1000 -nt AUTO \
        -pre iqtree/otus

# cd ${wd}/result/tree
Rscript ./${db}/script/table2itol.R -a -c double -D plan1 -i OTUID -l Genus -t %s -w 0.5 annotation.txt


## 
Rscript ./${db}/script/table2itol.R -a -d -c none -D plan2 -b Phylum -i OTUID -l Genus -t %s -w 0.5 annotation.txt

## 
Rscript ./${db}/script/table2itol.R -c keep -D plan3 -i OTUID -t %s otutab.txt

##
Rscript ./${db}/script/table2itol.R -a -c factor -D plan4 -i OTUID -l Genus -t %s -w 0 annotation.txt

cd ${wd}

#