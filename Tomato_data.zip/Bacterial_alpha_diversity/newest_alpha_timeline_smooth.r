options(warn = -1) # Turn off warning
site="https://mirrors.tuna.tsinghua.edu.cn/CRAN"
if (!suppressWarnings(suppressMessages(require("optparse", character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))) {
  install.packages("optparse", repos=site)
  require("optparse",character.only=T) 
}
if (TRUE){
  option_list <- list(
    make_option(c("-i", "--input"), type="character", default="./TimeLine.txt",
                help="Input table file to read; Alpha [default %default]"),
    make_option(c("-t", "--type"), type="character", default="richness",
                help="type of alpha index;  [default %default]"),
    make_option(c("-d", "--design"), type="character", default="./metadata.tsv",
                help="design file; [default %default]"),
    make_option(c("-n", "--group"), type="character", default="group",
                help="name of group type; [default %default]"),
    make_option(c("-w", "--width"), type="numeric", default=10,
                help="Width of figure; [default %default]"),
    make_option(c("-e", "--height"), type="numeric", default=8,
                help="Height of figure;  [default %default]"),
    make_option(c("-o", "--output"), type="character", default="",
                help="output directory or prefix; pdf [default %default]")
  )
  opts <- parse_args(OptionParser(option_list=option_list))
  
  if (opts$output==""){
    opts$output=paste("./",opts$type, sep = "")}
  
  print(paste("The input file is ", opts$input,  sep = ""))
  print(paste("Type of alpha index is ", opts$type,  sep = ""))
  print(paste("The design file is ", opts$design,  sep = ""))
  print(paste("The group name is ", opts$group,  sep = ""))
  print(paste("Output figure width ", opts$width,  sep = ""))
  print(paste("Output figure height ", opts$height,  sep = ""))
  print(paste("The output file prefix is ", opts$output, sep = ""))
}

package_list <- c("reshape2","ggplot2","devtools","bindrcpp", "bindrcpp","agricolae","dplyr",
                  "ggthemes","agricolae","dplyr","gridExtra","ggsci")
for(p in package_list){
  if(!suppressWarnings(suppressMessages(require(p, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))){
    install.packages(p, repos=site)
    suppressWarnings(suppressMessages(library(p, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))
  }
}

package_list <- c("digest")
for(p in package_list){
  if(!suppressWarnings(suppressMessages(require(p, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))){
    source("https://bioconductor.org/biocLite.R")
    biocLite(p)
    suppressWarnings(suppressMessages(library(p, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))
  }
}

package_list <- c("kassambara/ggpubr")
for(p in package_list){
  q=unlist(strsplit(p,split = "/"))[2]
  if(!suppressWarnings(suppressMessages(require(q, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))){
    install_github(p)
    suppressWarnings(suppressMessages(library(q, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))
  }
}


alpha = read.table(opts$input, header=T, row.names=1, sep="\t", comment.char="") 

design = read.table(opts$design, header=T, row.names=1, sep="\t", comment.char="") 




data("alpha")
alpha$group <- factor(alpha$group, levels=c("day1", "day4", "day7", "day14","day21","day28","day35", "day42",ordered=TRUE))

###426600","#66CC99", "#009E73", "#0072B2","#990000","#FF0010","#2BCE48"
#CK: f7766d, BacCK:cc9501, FunCK:7bad00, CrossKCK:0bbd67, CKFOL:03bec3, BacFOL:0ea7fe, FunFOL:c67cfe, CrossKFOL:fe61cb 

color <- c("#cc9501","#0ea7fe","#0bbd67", "#fe61cb")

p1 <- ggplot(
  subset(alpha),#(alpha, shannon > 2.2 & richness > 600 )
  aes(x = group, y = richness, colour = Group1)
) +
  geom_point(alpha = 1) +
#size
  geom_smooth(aes(group=Group1),span=0.5,size=1.5, se=FALSE,method='lm',formula=y~I(poly(x,2)))+ theme_classic()+
  geom_jitter(height = 0.05) 
#  scale_color_manual(values = color)
p=p1 + scale_color_manual(values = color)
p
ggsave(paste(opts$output, "TimeLine_smooth.pdf", sep=""), p, width = 8, height = 5)

#colour <- c("#0bbd67","#fe61cb","#cc9501", "#0ea7fe", "#0072B2","#990000","#FF0010","#2BCE48");
##
p = ggplot(subset(alpha), aes(x=group, y=richness, color=Group1)) +
  geom_boxplot(position = "dodge", alpha=1, outlier.size=0.3, size=0.5, width=0.7, fill="transparent") +
  theme_classic() +# main_theme +
  geom_point( position=position_jitterdodge())+
  # geom_point(aes(shape = Group1, group = Group1), position=position_jitterdodge())
scale_color_manual(values = color)+

   #facet_grid(Pathogen ~ .)+
  theme(axis.text.x=element_text(angle=45,vjust=1, hjust=1))
p
ggsave(paste(opts$output, "Timeline_boxplot.pdf", sep=""), p, width = 8, height = 5)


sampFile = data.frame(group=design[,opts$group],
                      sample=row.names(design), 
                      row.names = row.names(design))
idx = rownames(sampFile) %in% rownames(alpha) # match design with alpha
sampFile = sampFile[idx,]
alpha = alpha[rownames(sampFile),] 

## richness index
# add design to alpha
#index = cbind(alpha[rownames(design),]$richness, sampFile) 
index = cbind(alpha[rownames(sampFile),][[opts$type]], sampFile) 
colnames(index) = c(opts$type,"group","sample") # add richness colname is value
#model = aov(richness ~ group, data=index)
model = aov(index[[opts$type]] ~ group, data=index)
Tukey_HSD <- TukeyHSD(model, ordered = TRUE, conf.level = 0.95)
Tukey_HSD_table <- as.data.frame(Tukey_HSD$group) 
Tukey_HSD_table
out <- LSD.test(model,"group", p.adj="none")
stat = out$groups
index$stat=stat[as.character(index$group),]$groups
max=max(index[,c(opts$type)])
min=min(index[,opts$type])
x = index[,c("group",opts$type)]

# y = x%>% group_by(group)%>% summarise(Max=max(richness))
y = x %>% group_by(group) %>% summarise_(Max=paste('max(',opts$type,')',sep=""))

y=as.data.frame(y)
rownames(y)=y$group
index$y=y[as.character(index$group),]$Max + (max-min)*0.05

# ggsave(paste(opts$output, ".png", sep=""), p, width = opts$width, height = opts$height)

write.table("\t", file=paste(opts$output,".txt",sep=""),append = F, quote = F, eol = "", row.names = F, col.names = F)
write.table(Tukey_HSD_table, file=paste(opts$output,".txt",sep=""), append = T, quote = F, sep="\t", eol = "\n", na = "NA", dec = ".", row.names = T, col.names = T)

print(paste("Output in ", opts$output, ".txt/pdf finished.", sep = ""))

