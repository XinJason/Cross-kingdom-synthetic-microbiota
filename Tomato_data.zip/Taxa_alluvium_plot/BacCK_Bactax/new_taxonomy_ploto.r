## Basic plotting stuff
# Set working enviroment in Rstudio
rm(list=ls()) # clean enviroment object
library("reshape2", quietly=T, warn.conflicts=F)
library("ggalluvial")
library("ggsci")
# Set ggplot2 drawing parameter, such as axis line and text size, lengend and title size, and so on.
main_theme = theme(panel.background=element_blank(),
                    panel.grid=element_blank(),
                    axis.line.x=element_line(size=.5, colour="black"),
                    axis.line.y=element_line(size=.5, colour="black"),
                    axis.ticks=element_line(color="black"),
                    axis.text=element_text(color="black", size=7),
                    legend.position="right",
                    legend.background=element_blank(),
                    legend.key=element_blank(),
                    legend.text= element_text(size=7),
                    text=element_text(family="sans", size=7))


design = read.table("./metadata.tsv", header=T, row.names= 1, sep="\t") 

otu_table = read.delim("./otutab_rare.txt", row.names= 1,  header=T, sep="\t")

taxonomy = read.delim("./rep_seqs_tax.txt", row.names= 1,header=F, sep="\t")
colnames(taxonomy) = c("kingdom","phylum","class","order","family","genus","species")

# topN taxonomy+class

# select p__Proteobacteria line
idx = taxonomy$kingdom == "k__Bacteria"
taxonomy$full=as.character(taxonomy$phylum) 
taxonomy[idx,]$full=as.character(taxonomy[idx,]$genus)
tax_count = merge(taxonomy, otu_table, by="row.names")
tax_count_sum = aggregate(tax_count[,-(1:9)], by=tax_count[9], FUN=sum) 
rownames(tax_count_sum) = tax_count_sum$full

tax_count_sum = tax_count_sum[,-1]
#normalize reads count
per = t(t(tax_count_sum)/colSums(tax_count_sum,na=T)) * 100 

mean_sort = per[(order(-rowSums(per))), ] 
colSums(mean_sort)

mean_sort=as.data.frame(mean_sort)
other = colSums(mean_sort[10:dim(mean_sort)[1], ])
mean_sort = mean_sort[1:(10-1), ]
mean_sort = rbind(mean_sort,other)
rownames(mean_sort)[10] = c("Low Abundance")
write.table(mean_sort, file="result/tax/Top10phylum_ProGenus.txt", append = F, sep="\t", quote=F, row.names=T, col.names=T)
topN=rownames(mean_sort)

sub_design = subset(design,group %in% c("day1","day4","day7","day14","day21","day28","day35","day42") )
sub_design$group=sub_design$group
sub_design$group  = factor(sub_design$group, levels=c("day1","day4","day7","day14","day21","day28","day35","day42"))
print(paste("Number of group: ",length(unique(sub_design$group)),sep="")) # show group numbers

idx = rownames(sub_design) %in% colnames(mean_sort) 
sub_design = sub_design[idx,]
mean_sort = mean_sort[, rownames(sub_design)] # reorder according to design

mean_sort$phylumpro = rownames(mean_sort)
data_all = as.data.frame(melt(mean_sort, id.vars=c("phylumpro")))
# group information
data_all = merge(data_all, sub_design[c("group")], by.x="variable", by.y = "row.names")


# plot
p = ggplot(data_all, aes(x=variable, y = value, fill = phylumpro )) + 
  geom_bar(stat = "identity",position="fill", width=1)+ 
  scale_y_continuous(labels = scales::percent) + 
  # group
  facet_grid( ~ group, scales = "free_x", switch = "x") +  main_theme +
  theme(axis.ticks.x = element_blank(), legend.position="top", axis.text.x = element_blank(), strip.background = element_blank())+
  xlab("Groups")+ylab("Percentage (%)")           

p
ggsave("result/tax/tax_stack_phylumpro_sample.pdf", p, width = 10, height = 6)


mat = mean_sort[,1:(dim(mean_sort)[2]-1)]
mat_t = t(mat)
mat_t2 = merge(sub_design[c("group")], mat_t, by="row.names")
mat_t2 = mat_t2[,-1]
mat_mean = aggregate(mat_t2[,-1], by=mat_t2[1], FUN=mean) # mean
mat_mean_final = do.call(rbind, mat_mean)[-1,]
geno = mat_mean$group
colnames(mat_mean_final) = geno
mat_mean_final = as.data.frame(mat_mean_final)
mat_mean_final$phylumpro = rownames(mat_mean_final)

data_all = as.data.frame(melt(mat_mean_final, id.vars=c("phylumpro")))

tax_sample = read.table("./result/tax/final_g_group.txt", header=T, row.names= 1, sep="\t", comment.char="") 


# normalize to reads count
tax_sample1 = t(t(tax_sample)/colSums(tax_sample,na=T)) * 100 

tax_sample=as.data.frame(tax_sample1)
tax_sample$tax = rownames(tax_sample)
data_all = as.data.frame(melt(tax_sample, id.vars=c("tax")))

data_all$variable  = factor(data_all$variable, levels=c("day1","day4","day7","day14","day21","day28","day35","day42"))

#alluvium plot
p = ggplot(data = data_all, aes(x = variable, y = value,weight = value, alluvium = tax)) +
  geom_alluvium(aes(fill = tax, colour = tax), alpha = .75) +
# theme(axis.text.x = element_text(angle = 45, hjust = 1),panel.border = element_blank())
  
  main_theme + 
  theme(
    panel.border = element_blank(),
    axis.text.x = element_blank(),
    axis.text.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
    ) +
 theme_classic() + 
  ggtitle("Genus changes among groups")
#+ scale_color_npg()
p+ scale_color_npg()

ggsave("result/tax/tax_alluvium_phylumpro.pdf", p, width = 8, height = 5)

##########################

p = ggplot(data_all, aes(x=variable, y = value, fill = tax )) + 
  geom_bar(stat = "identity",position="fill", width=0.7)+ 
  scale_y_continuous(labels = scales::percent) + 
  xlab("Groups")+ylab("Percentage (%)")+main_theme+ theme(axis.text.x = element_text(angle = 45, hjust = 1)) 
p
ggsave("result/tax/tax_stack_phylumpro.pdf", p, width = 8, height = 5)

##################
Palette <- c("#B2182B","#E69F00","#56B4E9","#009E73","#F0E442","#0072B2","#D55E00","#CC79A7","#CC6666","#9999CC","#66CC99","#999999","#ADD1E5")
p <- ggplot(data_all,aes(x = variable, y = value, alluvium = tax, stratum = tax))
p1 <- p + geom_alluvium(aes(fill = tax),alpha = .5,width = 0.6) + 
  geom_stratum(aes(fill = tax),width = 0.6)

p2 <- p1 + ylab(label = "Relative Abundance") + xlab(label = "")

#p3 <- p2 + scale_fill_manual(values = Palette)
p3 <- p2 +scale_color_npg()

p4 <- p3 + theme_bw()+ theme(panel.grid=element_blank()) + 
  theme(panel.border = element_blank()) +
  theme(panel.background=element_rect(fill='transparent', 
                                      color='black'),plot.margin = unit(c(3,5,1,1),"mm"))
p5 <- p4 + theme(axis.text.x=element_text(colour="black",size=12,face = "bold",angle = -90,vjust = 0.5,hjust = 0)) + 
  theme(axis.text.y=element_text(colour = "black",size = 18)) + 
  theme(axis.line = element_line(colour = "black"))+ 
  theme(axis.title.y = element_text(size = 24,face = "bold",
                                   margin = unit(c(0,1,0,1),"lines")))
p6 <- p5 + theme(text = element_text(family = "Times"))

#p7 <- p5 + scale_y_continuous(limits = c(0,1),expand = c(0,0))

ggsave("result/tax/Connected_taxa.pdf", p6, width = 12, height = 12)

